import cv2
caaap = cv2.VideoCapture("Dharma Durai (2016) Single Part (480x320).mp4");#just remove the zero and give the file name with extentsion
fourcc = cv2.VideoWriter_fourcc('X','V','I','D')

out =  cv2.VideoWriter('output.mp4',fourcc,20.0,(480,320))#any format .mp4 or .avi can be given just for name sake



print(caaap.isOpened())
while(caaap.isOpened()):
    ret, frame =caaap.read()
    if ret == True:

        print(caaap.get(cv2.CAP_PROP_FRAME_WIDTH))
        print(caaap.get(cv2.CAP_PROP_FRAME_HEIGHT))

        out.write(frame)

        gray =cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        cv2.imshow('frame',gray)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    else:
        break
caaap.release()
out.release()
cv2.destroyAllWindows()
